<?php

require_once(__ROOT__ . "view/View.php");

class ViewExport extends View
{	
  //include"CompanyView.php";
  }
?>
