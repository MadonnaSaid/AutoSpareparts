<?php
LocalCompanyID
require_once(__ROOT__ . "controller/Controller.php");
class AddCompanyController extends Controller
{
	public function Con_addCompany()
	{
		$LocalCompanyID=$_POST['LocalCompanyID'];
		$Name=$_POST['CompanyName'];
		$email=$_POST['email'];
		$phoneNumber=$_POST['phoneNumber'];
		$RegisterSupplierNumber=$_POST['RegisterSupplierNumber'];
		$CommercialRecord=$_POST['CommercialRecord'];
		
		$this->model-> addcompany($CompanyName, $email, $phoneNumber,$RegisterSupplierNumber, $CommercialRecord);
	}
	public function edit($LocalCompanyID)
	 {
		$CompanyName = $_REQUEST['CompanyName'];
		$email = $_REQUEST['email'];
        $phoneNumber = $_REQUEST['phoneNumber'];
		$RegisterSupplierNumber = $_REQUEST['RegisterSupplierNumber'];
		$CommercialRecord = $_REQUEST['CommercialRecord'];

		$this->model->addcompany($LocalCompanyID)->editCompany($CompanyName, $email, $phoneNumber,$RegisterSupplierNumber, $CommercialRecord);
	}

	public function delete($LocalCompanyID)
	{
		$this->model->addcompany($LocalCompanyID)->deleteCompany();
	}
}
?>