<?php
require_once(__ROOT__ . "model/Model.php");
require_once(__ROOT__ . "model/AddCompanyModel.php");

class AddCompanysModel extends Model 
{
	private $addcompanysmodel;
	function __construct() {
		$this->fillArray();
	}

	function fillArray() {
		$this->addcompanysmodel = array();
		$this->db = $this->connect();
		$result = $this->readMovies();
		while ($row = $result->fetch_assoc()) {
			array_push($this->addcompanysmodel, new AddCompanyModel($row["LocalCompanyID"]));
		}
	}

	function addcompany($CompanyName,$email,$phoneNumber,$RegisterSupplierNumber, $CommercialRecord)
		{
		
		$sql="INSERT INTO `localcompany`
		( `CompanyName`, 
		`email`, 
		`phoneNumber`,
		`RegisterSupplierNumber`, 
		`CommercialRecord`) 
		VALUES (
			'$Name',
			'$email',
			'$phoneNumber',
			'$RegisterSupplierNumber', 
			'$CommercialRecord')";

			mysqli_query($con,$sql);
		}

	function insertCompany($CompanyName, $email,$phoneNumber,$RegisterSupplierNumber,$CommercialRecord){
		$sql = "INSERT INTO localcompany (CompanyName, phoneNumber, RegisterSupplierNumber, CommercialRecord) VALUES ('".$_SESSION['LocalCompanyID']."','$CompanyName', '$email', $'phoneNumber' ,$'RegisterSupplierNumber')";
		if($this->db->query($sql) === true){
			echo "Records inserted successfully.";
			$this->fillArray();
		} 
		else{
			echo "ERROR: Could not able to execute $sql. " . $conn->error;
		}
	}	
}