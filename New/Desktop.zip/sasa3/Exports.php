<?php
require_once(__ROOT__ . "model/Model.php");
require_once(__ROOT__ . "model/Export.php");

class Exports extends Model 
{
	private $Exports;
	function __construct() 
	{
		$this->fillArray();
	}

	function fillArray() 
	{
		$this->Exports = array();
		$this->db = $this->connect();
		$result = $this->readExport();
		while ($row = $result->fetch_assoc())
		{
			array_push($this->Exports, new Export($row["companyID"],$row["CarID"],$row["PartNumber"],$row["PartName"],$row["Quantity"],$row["itemPrice"],$row["TotalCost"]));
		}
	}

	function getExports() 
	{
		return $this->Exports;
	}

	function readExport()
	{
		$sql = "SELECT * FROM export";

		$result = $this->db->query($sql);
		if ($result->num_rows > -1){
			return $result;
		}
		else {
			return false;
		}
	}

	function Model_insertExport($CarID,$PartNumber,$PartName, $Quantity, $itemPrice, $TotalCost)
	{
		$sql = "INSERT INTO export 
		(
		CarID,
		PartNumber,
		PartName,
		Quantity,
		itemPrice,
		TotalCost
		)
		VALUES
		(
		 '$CarID',
		 '$PartNumber',
		 '$PartName',
		 '$Quantity',
		  '$itemPrice',
		   '$TotalCost'
		)";
		if($this->db->query($sql) === true)
		{
			echo "Records inserted successfully.";
			$this->fillArray();
		} 
		else{
			echo "ERROR: Could not able to execute $sql. " . $conn->error;
		}
	}
}
?>