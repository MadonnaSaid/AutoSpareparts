<?php
  require_once(__ROOT__ . "model/Model.php");
?>

<?php
class Export extends Model 
{
	private $companyID;
    private $CarID;
    private $PartNumber;
    private $PartName;    
    private $Quantity;
	private $itemPrice;
    private $TotalCost;

 function __construct($companyID,$CarID="",$PartNumber="",$PartName="",$Quantity="",$itemPrice="",$TotalCost="")
  {
    $this->companyID = $companyID;
	    $this->db = $this->connect();

    if(""===$CarID)
    {
      $this->readUser($companyID);
    }
    else
    {
      $this->CarID = $CarID;
      $this->PartNumber=$PartNumber;
      $this->PartName=$PartName;
	  $this->Quantity=$Quantity;
      $this->itemPrice = $itemPrice;
      $this->TotalCost = $TotalCost;
    }
  }

  function getCarID()
  {
  	return $this->CarID;
  }
  function setCarID($CarID)
  {
  	 return $this->CarID = $CarID;
  }
  function getPartNumber()
  {
  	return $this->PartNumber=$PartNumber;
  }
  function setPartNumber($PartNumber)
  {
  	return $this->PartNumber=$PartNumber; 
  }
  function getPartName()
  {
  	return  $this->PartName=$PartName;
  }
  function setPartName($PartName)
  {
  	return  $this->PartName=$PartName;
  }
  function getQuantity()
  {
  	 $this->Quantity=$Quantity;
  }
  function setQuantity($Quantity)
  {
  	 $this->Quantity=$Quantity;
  }
  function getitemPrice() 
  {
    return $this->itemPrice;
  }
  function setitemPrice($itemPrice)
  {
    return $this->itemPrice = $itemPrice;
  }
  
  function getTotalCost()
  {
    return $this->TotalCost;
  }
  
  function setPhone($TotalCost) 
  {
    return $this->TotalCost = $TotalCost;
  }

  function getcompanyID()
  {
  	return $this->companyID;
  }

  function readExport($companyID)
  {
  	$Export=" SELECT * FROM export where companyID=".$companyID;
  	$db = $this->connect();

    $result = $db->query($Export);

    if ($result->num_rows == 1)
    {
        $row = $db->fetchRow();
        $this->CarID = $row["CarID"];
		$_SESSION["CarID"]=$row["CarID"];
		$this->PartNumber=$row["PartNumber"];
		$this->PartName=$row["PartName"];
		$this->Quantity=$row["Quantity"];
        $this->itemPrice = $row["itemPrice"];
		$this->TotalCost = $row["TotalCost"];
    }
    else 
    {
    	$this->CarID="";
    	$this->PartNumber="";
    	$this->PartName="";
    	$this->Quantity="";
    	$this->itemPrice="";
    	$this->TotalCost="";
    }
  }

  function Model_editExport($CarID,$PartNumber,$PartName,$Quantity,$itemPrice,$TotalCost)
	{
		$editExport="UPDATE export SET CarID='$CarID', PartNumber='$PartNumber',PartName='$PartName',Quantity='$Quantity , itemPrice='$itemPrice', TotalCost='$TotalCost' WHERE companyID=$this->companyID; ";
		if($this->db->query($editExport)===true)
		{
			echo"updated successfully.";
			$this->readExport($this->companyID);
		}
		else
		{
            echo "ERROR: Could not able to execute $sql. " . $conn->error;
    	}
	}

	function Model_deleteExport()
	{				
		$deleteExport="DELETE FROM export WHERE companyID=$this->companyID;";
		if($this->db->query($deleteExport)===true)
		{
			 echo "deletet successfully.";
		}
		else
		{
            echo "ERROR: Could not able to execute $sql. " . $conn->error;
        }
	}

	//fadel edit employee henas
}
?>