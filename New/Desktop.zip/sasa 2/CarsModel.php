<?php
require_once(__ROOT__ . "model/Model.php");
require_once(__ROOT__ . "model/CarModel.php");

class CarsModel extends Model 
{
	private $Carsmodel;
	function __construct()
	{
		$this->fillArray();
	}

	function fillArray() 
	{
		$this->Carsmodel = array();
		$this->db = $this->connect();
		$result = $this->readMovies();
		while ($row = $result->fetch_assoc()) 
		{
			array_push($this->Carsmodel, new AddCompanyModel($row["CarID"]));
		}
	}
	function addcar($CarName, $CarModel,$CarYear)
	{
		
		$sql="INSERT INTO `car`
		( `CarName`, 
		  `CarModel`, 
		  `CarYear`) 
		VALUES (
			'$CarName',
			'$CarModel',
			'$CarYear')";
			mysqli_query($con,$sql);
	}
}