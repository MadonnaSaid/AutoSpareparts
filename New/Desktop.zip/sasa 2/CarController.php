<?php
LocalCompanyID
require_once(__ROOT__ . "controller/Controller.php");
class CarController extends Controller
{	
	public function Con_Car()
	{
		$CarID=$_POST['CarID'];
		$CarName=$_POST['CarName'];
		$CarModel=$_POST['CarModel'];
		$CarYear=$_POST['CarYear'];
		
		$this->model-> addcar($CarName, $CarModel,$CarYear);
	}
	public function edit($LocalCompanyID)
	 {
		$CompanyName = $_REQUEST['CompanyName'];
		$email = $_REQUEST['email'];
        $phoneNumber = $_REQUEST['phoneNumber'];
		$RegisterSupplierNumber = $_REQUEST['RegisterSupplierNumber'];
		$CommercialRecord = $_REQUEST['CommercialRecord'];

		$this->model->addcar($CarID)->editCar($CarName, $CarModel,$CarYear);
	}

	public function delete($CarID)
	{
		$this->model->addcompany($CarID)->deleteCar();
	}
}
?>