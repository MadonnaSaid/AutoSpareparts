<?php
require_once(__ROOT__ . "model/Model.php");

class AddCompanyModel extends Model
{
	private $CarID;
	private $CarName;
	private $CarModel;
	private $CarYear;
	private $imgID;

	function __construct($CarID, $CarName="",$CarModel="",$CarYear="",$imgID="")
	{
		$this->CarID = $CarID;
		$this->db = $this->connect();

		if(""===$CarName)
		{
			$this->readCar($CarID);
		}
		else
		{
			$this->CarName = $CarName;
			$this->CarModel = $CarModel;
			$this->CarYear = $CarYear;
			$this->imgID = $imgID;
		}
	}

	function getCarID() 
	{
		return $this->CarID;
	}	
	function setCarID($CarID)
	{
		return $this->CarID = $CarID;
	}

	function getCarName() 
	{
		return $this->CarName;
	}	
	function setCarName($CarName)
	{
		return $this->CarName = $CarName;
	}

	function getCarModel()) 
	{
		return $this->CarModel;
	}
	function setCarModel($CarModel) 
	{
		return $this->CarModel = $CarModel;
	}

	function getCarYear() 
	{
		return $this->CarYear;
	}
	function setCarYear($CarYear) 
	{
		return $this->CarYear = $CarYear;
	}

	function getimgID() 
	{
		return $this->imgID;
	}	
	function setimgID($imgID)
	{
		return $this->imgID = $imgID;
	}

	function readCar($CarID)
	{
		$sql = "SELECT * FROM car where ID=".$CarID;
		$db = $this->connect();
		$result = $db->query($sql);
		if ($result->num_rows == 1){
			$row = $db->fetchRow();

			$this->CarName = $row["CarName"];
			$this->CarModel = $row["CarModel"];
			$this->CarYear = $row["CarYear"];
		}
		else 
		{
			$this->CarName = "";
			$this->CarModel = "";
			$this->CarYear= "";
		}	
	}

	function editCar($CarName, $CarModel,$CarYear)
	{
		$sql = "update comany set name='$CarName',model='$CarModel' ,year='CarYear' where id=$this->CarID;";
		if($this->db->query($sql) === true){
			echo "updated successfully.";
			$this->readCompany($this->id);
		} 
		else
		{
			echo "ERROR: Could not able to execute $sql. " . $conn->error;
		}
	}

	function deleteCar()
	{
		$sql="DELETE sparepart
			  FROM sparepart
			  INNER JOIN car ON sparepart.PartNumber = car.CarID AND delete car where id = id";
		if($this->db->query($sql) === true)
		{
			echo "deleted successfully.";
		} 
		else
		{
			echo "ERROR: Could not able to execute $sql. " . $conn->error;
		}
	}

	function imageCar()
	{
		$sql="insert into img (img) 
			  SELECT BulkColumn 
			  FROM Openrowset( Bulk 'image..Path..here', Single_Blob) as img";
		if($this->db->query($sql) === true)
		{
			echo "added successfully.";
		} 
		else
		{
			echo "ERROR: Could not able to execute $sql. " . $conn->error;
		}
	}
}